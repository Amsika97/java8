package com.maveric.org;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseInteractionApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseInteractionApplication.class, args);
	}

}
